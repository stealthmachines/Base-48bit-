class SymbolNode:
    def __init__(self, expression, depth=0):
        self.expression = expression
        self.children = []
        self.depth = depth
        self.hash = hash(expression + str(depth))

    def add_child(self, child):
        self.children.append(child)

    def reduce(self):
        if not self.children:
            return self.expression
        return ''.join(child.reduce() for child in self.children)