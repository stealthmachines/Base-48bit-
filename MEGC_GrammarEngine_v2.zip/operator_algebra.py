TRINARY_PRIMITIVES = ['+', '*', '^']
EXOTIC_OPERATORS = ['⊗', '⧝', '⨀', '⟠', '⋇']

def evolve_operator(nesting_depth):
    return EXOTIC_OPERATORS[nesting_depth % len(EXOTIC_OPERATORS)]