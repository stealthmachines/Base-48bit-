from recursive_reducer import recursive_encode
from symbol_fuser import fuse_symbol_tree

data = "THE QUICK BROWN FOX"
tree = recursive_encode(data)
glyph = fuse_symbol_tree(tree)

print(f"Fully reduced: {glyph}")