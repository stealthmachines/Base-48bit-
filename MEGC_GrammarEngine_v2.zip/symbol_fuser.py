def fuse_symbol_tree(root):
    reduced = root.reduce()
    symbolic_value = sum(ord(c) for c in reduced) % 0x10FFFF
    return chr(symbolic_value)