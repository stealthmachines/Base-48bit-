from grammar_engine import SymbolNode
from operator_algebra import evolve_operator

def recursive_encode(data, depth=0):
    if depth > 8 or len(data) <= 1:
        return SymbolNode(expression=data, depth=depth)

    op = evolve_operator(depth)
    left = recursive_encode(data[:len(data)//2], depth+1)
    right = recursive_encode(data[len(data)//2:], depth+1)

    node = SymbolNode(expression=f"({op})", depth=depth)
    node.add_child(left)
    node.add_child(right)
    return node