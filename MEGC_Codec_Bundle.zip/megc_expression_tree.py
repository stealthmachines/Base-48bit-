# Builds nested operator trees from string input

def build_tree(data):
    return {'val': data, 'left': None, 'right': None}  # Placeholder
