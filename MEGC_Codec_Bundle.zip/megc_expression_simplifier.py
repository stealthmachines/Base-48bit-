# Reduces expression into simplest fixed-point

def simplify(expr):
    return expr.split()[0]  # Naive simplifier
