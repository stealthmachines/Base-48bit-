# Parses strings using Formula A–D and reduces them recursively

def formula_A(n, r):
    from math import pi
    return (1.618 * 9.81 * 2**n * pi) / (r**3)

def formula_B(n, r):
    from math import sqrt, log
    return ((1.618**n / sqrt(5)) / (n * log(n))) * (1/r**2)

def recursive_reduce(s):
    return f"[{s}]"  # Simplified recursive wrap
