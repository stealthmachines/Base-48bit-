# Tool to generate frozen Base4096 alphabet
import unicodedata

ALPHABET = []
for i in range(0x2000, 0x3000):
    try:
        name = unicodedata.name(chr(i))
        if 'CONTROL' not in name and 'PRIVATE USE' not in name:
            ALPHABET.append(chr(i))
    except ValueError:
        continue

print(f"Frozen alphabet length: {len(ALPHABET)}")
