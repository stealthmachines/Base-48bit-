# Master encoder: collapse to one symbol
from megc_symbol_packager import pack

def collapse(data):
    return pack(data)
