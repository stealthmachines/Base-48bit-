# Maps string to symbol in complex base space

def pack(data):
    return chr(sum(ord(c) for c in data) % 0x10FFFF)  # Very crude packer
