# Frozen Base4096 Alphabet
ALPHABET = [chr(i) for i in range(0x2000, 0x3000)]  # Placeholder, refine later
