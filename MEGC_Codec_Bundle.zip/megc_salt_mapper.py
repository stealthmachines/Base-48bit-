# Uses salt as the full message and maps its expansions

def map_salt(salt):
    return [ord(c) for c in salt]
