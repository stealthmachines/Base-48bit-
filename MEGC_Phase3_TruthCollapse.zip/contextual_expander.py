EXOTIC_GRAMMAR = ['⊗', '⧝', '⨀', '⟠', '⋇', '↯', '∞', 'ψ', 'Ω', '∑']

def entropy_gradient(data):
    return sum(ord(c) for c in data) % len(EXOTIC_GRAMMAR)

def select_operator(data):
    return EXOTIC_GRAMMAR[entropy_gradient(data)]

def expand_with_context(data, depth=0):
    if len(data) <= 1 or depth > 5:
        return data
    op = select_operator(data)
    mid = len(data) // 2
    left = expand_with_context(data[:mid], depth+1)
    right = expand_with_context(data[mid:], depth+1)
    return f"{op}({left},{right})"