import math

PHI = (1 + math.sqrt(5)) / 2

def formula_a(k_omega, phi, Fn, n, Pn, omega, r):
    return (k_omega * phi * Fn * 2**n * Pn * omega) / (r**3)

def formula_b(n, r):
    if n <= 1: return 1  # prevent log(0) and division by zero
    return ((PHI**n) / math.sqrt(5)) / (n * math.log(n)) * (1 / r**2)

def is_identity_collapse(k_omega, Fn, n, Pn, omega, r, tolerance=1e-9):
    fa = formula_a(k_omega, PHI, Fn, n, Pn, omega, r)
    fb = formula_b(n, r)
    return abs(fa - fb) < tolerance