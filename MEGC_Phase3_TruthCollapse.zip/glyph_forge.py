from contextual_expander import expand_with_context

def forge_symbol(data):
    expanded = expand_with_context(data)
    symbolic_value = sum(ord(c) for c in expanded) % 0x10FFFF
    return chr(symbolic_value)

def forge_and_print(data):
    symbol = forge_symbol(data)
    print(f"Symbolic output: {symbol} from input: '{data}'")